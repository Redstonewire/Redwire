package com.redwire.items;
import net.minecraft.item.Item;

public class dopedingots extends Item
{

        public dopedingots(int id)
        {
                super(id);
        }

}