package com.redwire.items;

import net.minecraft.item.Item;

public class pliers extends Item
{

    public pliers(int id)
    {
        super(id);
    }

}
