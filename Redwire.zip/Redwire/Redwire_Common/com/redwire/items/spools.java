package com.redwire.items;

import net.minecraft.item.Item;

public class spools extends Item {

    public spools(int id) {
        super(id);
        // TODO Auto-generated constructor stub
    }

}
