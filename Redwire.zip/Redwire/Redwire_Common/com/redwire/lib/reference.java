package com.redwire.lib;

public class reference
{
    public static final String MOD_ID = "RW";
    public static final String MOD_NAME = "Redwire";
    public static final String VERSION = "0.0.1preA";
}
