package com.redwire.machines;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

public class dyer extends Block 
{
    
    public dyer(int id)
   {
        super(id, Material.grass);
        setHardness(1.0F);
        setStepSound(Block.soundGrassFootstep);
        setUnlocalizedName("Dyer");
        this.setCreativeTab(com.redwire.Redwire.Redtab);
   }
 
}
