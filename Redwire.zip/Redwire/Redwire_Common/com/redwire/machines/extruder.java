package com.redwire.machines;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

public class extruder extends Block 
{

    public extruder(int id)
    {
        super(id, Material.grass);
        setHardness(1.0F);
        setStepSound(Block.soundGrassFootstep);
        setUnlocalizedName("Extruder");
        this.setCreativeTab(com.redwire.Redwire.Redtab);
    }

}
