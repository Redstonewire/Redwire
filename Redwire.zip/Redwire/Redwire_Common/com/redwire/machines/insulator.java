package com.redwire.machines;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

public class insulator extends Block
{
    
    public insulator(int id)
    {
        super(id, Material.grass);
        setHardness(1.0F);
        setStepSound(Block.soundGrassFootstep);
        setUnlocalizedName("Insulator");
        this.setCreativeTab(com.redwire.Redwire.Redtab);
   }

}
