package com.redwire.machines;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

public class winder extends Block
{

    public winder(int id)
    {
        super(id, Material.grass);
        setHardness(1.0F);
        setStepSound(Block.soundGrassFootstep);
        setUnlocalizedName("Winder");
        setCreativeTab(com.redwire.Redwire.Redtab);
   }

}
