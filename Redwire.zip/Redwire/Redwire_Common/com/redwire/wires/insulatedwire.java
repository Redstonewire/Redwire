package com.redwire.wires;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

public class insulatedwire extends Block {

        public insulatedwire(int id) {
            super(id, Material.cloth);
            setHardness(1.0F);
            setStepSound(Block.soundClothFootstep);
            setUnlocalizedName("insulatedwire");
            this.setCreativeTab(com.redwire.Redwire.Redtab);

    }

}
