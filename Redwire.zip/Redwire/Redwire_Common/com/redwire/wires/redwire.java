package com.redwire.wires;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

public class redwire extends Block {
    
        public redwire(int id) {
            super(id, Material.cloth);
            setHardness(1.0F);
            setStepSound(Block.soundClothFootstep);
            setUnlocalizedName("redwire");
            this.setCreativeTab(com.redwire.Redwire.Redtab);
        }
}
